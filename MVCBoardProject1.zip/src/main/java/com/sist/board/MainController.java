package com.sist.board;

import com.sist.controller.Controller;

@Controller("mc")
public class MainController {

}
