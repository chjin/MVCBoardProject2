package com.sist.board;

import com.sist.controller.Controller;

@Controller("sc")
public class SearchController {

}
